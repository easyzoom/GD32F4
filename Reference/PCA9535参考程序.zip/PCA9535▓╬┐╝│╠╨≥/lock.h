
#ifndef __LOCK_H
#define __LOCK_H

#ifdef __cplusplus
extern "C" {
#endif


#include <stdio.h>
#include <string.h>
#include "cmsis_os.h"
#include "stm32l4xx_hal.h"

// PCA9535命令宏
#define  TCA9535_INPUT_PORT0_REG        0
#define  TCA9535_INPUT_PORT1_REG        1

#define  TCA9535_OUTPUT_PORT0_REG       2
#define  TCA9535_OUTPUT_PORT1_REG       3

#define  TCA9535_INVERSION_PORT0_REG    4
#define  TCA9535_INVERSION_PORT1_REG    5

#define  TCA9535_CONFIG_PORT0_REG       6
#define  TCA9535_CONFIG_PORT1_REG       7

#define  TCA9535_CONFIG_INPUT_VAL       0xFF
#define  TCA9535_CONFIG_OUTPUT_VAL      0x00


int pca9535_init(void);
HAL_StatusTypeDef pca9535_write(uint8_t *pData, uint16_t size);
HAL_StatusTypeDef pca9535_read(uint8_t cmd, uint8_t *pData, uint16_t size);



#ifdef __cplusplus
}
#endif

#endif /* __LOCK_H */
