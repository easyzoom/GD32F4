#include "stm32l4xx_hal.h"
#include "lock.h"


// 地址最后一位表示读（1）/写（0），短接A0、A1、A2至GND
#define			PCA9535_ADDR				(0x40)			//	0100 000 0

// copy from stm32l4xx_hal_i2c.c
#define TIMING_CLEAR_MASK   (0xF0FFFFFFU)  /*!< I2C TIMING clear register Mask */
#define I2C_TIMEOUT_ADDR    (10000U)       /*!< 10 s  */
#define I2C_TIMEOUT_BUSY    (25U)          /*!< 25 ms */
#define I2C_TIMEOUT_DIR     (25U)          /*!< 25 ms */
#define I2C_TIMEOUT_RXNE    (25U)          /*!< 25 ms */
#define I2C_TIMEOUT_STOPF   (25U)          /*!< 25 ms */
#define I2C_TIMEOUT_TC      (25U)          /*!< 25 ms */
#define I2C_TIMEOUT_TCR     (25U)          /*!< 25 ms */
#define I2C_TIMEOUT_TXIS    (25U)          /*!< 25 ms */
#define I2C_TIMEOUT_FLAG    (25U)          /*!< 25 ms */

#define MAX_NBYTE_SIZE      255U
#define SlaveAddr_SHIFT     7U
#define SlaveAddr_MSK       0x06U


unsigned int g_lock_EI = 0;

extern I2C_HandleTypeDef hi2c1;


// copy from stm32l4xx_hal_i2c.c
#if 1
static HAL_StatusTypeDef I2C_WaitOnFlagUntilTimeout(I2C_HandleTypeDef *hi2c, uint32_t Flag, FlagStatus Status, uint32_t Timeout, uint32_t Tickstart)
{
  while (__HAL_I2C_GET_FLAG(hi2c, Flag) == Status)
  {
    /* Check for the Timeout */
    if (Timeout != HAL_MAX_DELAY)
    {
      if (((HAL_GetTick() - Tickstart) > Timeout) || (Timeout == 0U))
      {
        hi2c->ErrorCode |= HAL_I2C_ERROR_TIMEOUT;
        hi2c->State = HAL_I2C_STATE_READY;
        hi2c->Mode = HAL_I2C_MODE_NONE;

        /* Process Unlocked */
        __HAL_UNLOCK(hi2c);
        return HAL_ERROR;
      }
    }
  }
  return HAL_OK;
}

static void I2C_TransferConfig(I2C_HandleTypeDef *hi2c, uint16_t DevAddress, uint8_t Size, uint32_t Mode, uint32_t Request)
{
  /* Check the parameters */
  assert_param(IS_I2C_ALL_INSTANCE(hi2c->Instance));
  assert_param(IS_TRANSFER_MODE(Mode));
  assert_param(IS_TRANSFER_REQUEST(Request));

  /* update CR2 register */
  MODIFY_REG(hi2c->Instance->CR2, ((I2C_CR2_SADD | I2C_CR2_NBYTES | I2C_CR2_RELOAD | I2C_CR2_AUTOEND | (I2C_CR2_RD_WRN & (uint32_t)(Request >> (31U - I2C_CR2_RD_WRN_Pos))) | I2C_CR2_START | I2C_CR2_STOP)), \
             (uint32_t)(((uint32_t)DevAddress & I2C_CR2_SADD) | (((uint32_t)Size << I2C_CR2_NBYTES_Pos) & I2C_CR2_NBYTES) | (uint32_t)Mode | (uint32_t)Request));
}

static void I2C_Flush_TXDR(I2C_HandleTypeDef *hi2c)
{
  /* If a pending TXIS flag is set */
  /* Write a dummy data in TXDR to clear it */
  if (__HAL_I2C_GET_FLAG(hi2c, I2C_FLAG_TXIS) != RESET)
  {
    hi2c->Instance->TXDR = 0x00U;
  }

  /* Flush TX register if not empty */
  if (__HAL_I2C_GET_FLAG(hi2c, I2C_FLAG_TXE) == RESET)
  {
    __HAL_I2C_CLEAR_FLAG(hi2c, I2C_FLAG_TXE);
  }
}

static HAL_StatusTypeDef I2C_IsAcknowledgeFailed(I2C_HandleTypeDef *hi2c, uint32_t Timeout, uint32_t Tickstart)
{
  if (__HAL_I2C_GET_FLAG(hi2c, I2C_FLAG_AF) == SET)
  {
    /* Wait until STOP Flag is reset */
    /* AutoEnd should be initiate after AF */
    while (__HAL_I2C_GET_FLAG(hi2c, I2C_FLAG_STOPF) == RESET)
    {
      /* Check for the Timeout */
      if (Timeout != HAL_MAX_DELAY)
      {
        if (((HAL_GetTick() - Tickstart) > Timeout) || (Timeout == 0U))
        {
          hi2c->ErrorCode |= HAL_I2C_ERROR_TIMEOUT;
          hi2c->State = HAL_I2C_STATE_READY;
          hi2c->Mode = HAL_I2C_MODE_NONE;

          /* Process Unlocked */
          __HAL_UNLOCK(hi2c);

          return HAL_ERROR;
        }
      }
    }

    /* Clear NACKF Flag */
    __HAL_I2C_CLEAR_FLAG(hi2c, I2C_FLAG_AF);

    /* Clear STOP Flag */
    __HAL_I2C_CLEAR_FLAG(hi2c, I2C_FLAG_STOPF);

    /* Flush TX register */
    I2C_Flush_TXDR(hi2c);

    /* Clear Configuration Register 2 */
    I2C_RESET_CR2(hi2c);

    hi2c->ErrorCode |= HAL_I2C_ERROR_AF;
    hi2c->State = HAL_I2C_STATE_READY;
    hi2c->Mode = HAL_I2C_MODE_NONE;

    /* Process Unlocked */
    __HAL_UNLOCK(hi2c);

    return HAL_ERROR;
  }
  return HAL_OK;
}

static HAL_StatusTypeDef I2C_WaitOnTXISFlagUntilTimeout(I2C_HandleTypeDef *hi2c, uint32_t Timeout, uint32_t Tickstart)
{
  while (__HAL_I2C_GET_FLAG(hi2c, I2C_FLAG_TXIS) == RESET)
  {
    /* Check if a NACK is detected */
    if (I2C_IsAcknowledgeFailed(hi2c, Timeout, Tickstart) != HAL_OK)
    {
      return HAL_ERROR;
    }

    /* Check for the Timeout */
    if (Timeout != HAL_MAX_DELAY)
    {
      if (((HAL_GetTick() - Tickstart) > Timeout) || (Timeout == 0U))
      {
        hi2c->ErrorCode |= HAL_I2C_ERROR_TIMEOUT;
        hi2c->State = HAL_I2C_STATE_READY;
        hi2c->Mode = HAL_I2C_MODE_NONE;

        /* Process Unlocked */
        __HAL_UNLOCK(hi2c);

        return HAL_ERROR;
      }
    }
  }
  return HAL_OK;
}

static HAL_StatusTypeDef I2C_WaitOnRXNEFlagUntilTimeout(I2C_HandleTypeDef *hi2c, uint32_t Timeout, uint32_t Tickstart)
{
  while (__HAL_I2C_GET_FLAG(hi2c, I2C_FLAG_RXNE) == RESET)
  {
    /* Check if a NACK is detected */
    if (I2C_IsAcknowledgeFailed(hi2c, Timeout, Tickstart) != HAL_OK)
    {
      return HAL_ERROR;
    }

    /* Check if a STOPF is detected */
    if (__HAL_I2C_GET_FLAG(hi2c, I2C_FLAG_STOPF) == SET)
    {
      /* Check if an RXNE is pending */
      /* Store Last receive data if any */
      if ((__HAL_I2C_GET_FLAG(hi2c, I2C_FLAG_RXNE) == SET) && (hi2c->XferSize > 0U))
      {
        /* Return HAL_OK */
        /* The Reading of data from RXDR will be done in caller function */
        return HAL_OK;
      }
      else
      {
        /* Clear STOP Flag */
        __HAL_I2C_CLEAR_FLAG(hi2c, I2C_FLAG_STOPF);

        /* Clear Configuration Register 2 */
        I2C_RESET_CR2(hi2c);

        hi2c->ErrorCode = HAL_I2C_ERROR_NONE;
        hi2c->State = HAL_I2C_STATE_READY;
        hi2c->Mode = HAL_I2C_MODE_NONE;

        /* Process Unlocked */
        __HAL_UNLOCK(hi2c);

        return HAL_ERROR;
      }
    }

    /* Check for the Timeout */
    if (((HAL_GetTick() - Tickstart) > Timeout) || (Timeout == 0U))
    {
      hi2c->ErrorCode |= HAL_I2C_ERROR_TIMEOUT;
      hi2c->State = HAL_I2C_STATE_READY;

      /* Process Unlocked */
      __HAL_UNLOCK(hi2c);

      return HAL_ERROR;
    }
  }
  return HAL_OK;
}

static HAL_StatusTypeDef I2C_WaitOnSTOPFlagUntilTimeout(I2C_HandleTypeDef *hi2c, uint32_t Timeout, uint32_t Tickstart)
{
  while (__HAL_I2C_GET_FLAG(hi2c, I2C_FLAG_STOPF) == RESET)
  {
    /* Check if a NACK is detected */
    if (I2C_IsAcknowledgeFailed(hi2c, Timeout, Tickstart) != HAL_OK)
    {
      return HAL_ERROR;
    }

    /* Check for the Timeout */
    if (((HAL_GetTick() - Tickstart) > Timeout) || (Timeout == 0U))
    {
      hi2c->ErrorCode |= HAL_I2C_ERROR_TIMEOUT;
      hi2c->State = HAL_I2C_STATE_READY;
      hi2c->Mode = HAL_I2C_MODE_NONE;

      /* Process Unlocked */
      __HAL_UNLOCK(hi2c);

      return HAL_ERROR;
    }
  }
  return HAL_OK;
}
#endif		// cpoy end



// 重载函数
void HAL_I2C_MasterRxCpltCallback(I2C_HandleTypeDef *hi2c)
{
	UNUSED(hi2c);

}


int pca9535_init(void)
{

	HAL_StatusTypeDef ret = HAL_OK;
	uint8_t data[] = {0x00, 0x00, 0x00};

#if 1
	// 上电先读取一次可能存在的意外中断
	memset(data, 0, sizeof(data));

	if (HAL_OK != (ret = pca9535_read(TCA9535_INPUT_PORT0_REG, data, 2)))
	{
		printf("pca9535_init_read fail, err = %d\r\n", ret);
		return -1;
	}
#endif

#if 1
	// 配置PCA9535 端口，即写配置寄存器，8输入，8输出，数据格式为：地址 + CMD + 8 input + 8 output
	data[0] = TCA9535_CONFIG_PORT0_REG;
	data[1] = TCA9535_CONFIG_INPUT_VAL;
	data[2] = TCA9535_CONFIG_OUTPUT_VAL;
	if (HAL_OK != (ret = pca9535_write(data, sizeof(data))))
	{
		printf("pca9535_init_write fail, err = %d\r\n", ret);
		return -1;
	}
#endif

   	return 0;
}


HAL_StatusTypeDef pca9535_write(uint8_t *pData, uint16_t size)
{
	return (HAL_I2C_Master_Transmit(&hi2c1, PCA9535_ADDR, pData, size, 1000));
}


//由于pca9535写过程需要restart信号，与 HAL_I2C_Master_Receive 接口稍有出入，故单独封装
HAL_StatusTypeDef pca9535_read(uint8_t cmd, uint8_t *pData, uint16_t size)
{
	int i = 0;
	uint32_t tickstart;
	uint32_t Timeout = 1000;
	uint16_t DevAddress = PCA9535_ADDR;		// 读取数据时硬件内部会将r/w位置1
	I2C_HandleTypeDef *hi2c = &hi2c1;

	// 先发送1字节地址 和 1字节CMD
	  if (hi2c->State == HAL_I2C_STATE_READY)
	  {
	    /* Process Locked */
	    __HAL_LOCK(hi2c);

	    /* Init tickstart for timeout management*/
	    tickstart = HAL_GetTick();

	    if (I2C_WaitOnFlagUntilTimeout(hi2c, I2C_FLAG_BUSY, SET, I2C_TIMEOUT_BUSY, tickstart) != HAL_OK)
	    {
	      return HAL_ERROR;
	    }

	    hi2c->State     = HAL_I2C_STATE_BUSY_TX;
	    hi2c->Mode      = HAL_I2C_MODE_MASTER;
	    hi2c->ErrorCode = HAL_I2C_ERROR_NONE;

	    /* Prepare transfer parameters */
	    hi2c->pBuffPtr  = &cmd;
	    hi2c->XferCount = sizeof(cmd);
	    hi2c->XferISR   = NULL;

	    /* Send Slave Address */
	    /* Set NBYTES to write and reload if hi2c->XferCount > MAX_NBYTE_SIZE and generate RESTART */
	    if (hi2c->XferCount > MAX_NBYTE_SIZE)
	    {
	      hi2c->XferSize = MAX_NBYTE_SIZE;
	      I2C_TransferConfig(hi2c, DevAddress, (uint8_t)hi2c->XferSize, I2C_RELOAD_MODE, I2C_GENERATE_START_WRITE);
	    }
	    else
	    {
	      hi2c->XferSize = hi2c->XferCount;
//	      I2C_TransferConfig(hi2c, DevAddress, (uint8_t)hi2c->XferSize, I2C_AUTOEND_MODE, I2C_GENERATE_START_WRITE);
	      I2C_TransferConfig(hi2c, DevAddress, (uint8_t)hi2c->XferSize, I2C_SOFTEND_MODE, I2C_GENERATE_START_WRITE);
	    }

	    while (hi2c->XferCount > 0U)
	    {
	      /* Wait until TXIS flag is set */
	      if (I2C_WaitOnTXISFlagUntilTimeout(hi2c, Timeout, tickstart) != HAL_OK)
	      {
	        return HAL_ERROR;
	      }
	      /* Write data to TXDR */
	      hi2c->Instance->TXDR = *hi2c->pBuffPtr;

	      /* Increment Buffer pointer */
	      hi2c->pBuffPtr++;
	      hi2c->XferCount--;
	      hi2c->XferSize--;
	    }

	    hi2c->State = HAL_I2C_STATE_READY;
	    hi2c->Mode  = HAL_I2C_MODE_NONE;

	    /* Process Unlocked */
	    __HAL_UNLOCK(hi2c);

//	    return HAL_OK;
	  }
	  else
	  {
	    return HAL_BUSY;
	  }

	  // Delay!!!
	  for (i = 0; i < 2000; i++){}

	  // Recv-------------

	   hi2c->State     = HAL_I2C_STATE_BUSY_RX;
	    hi2c->Mode      = HAL_I2C_MODE_MASTER;
	    hi2c->ErrorCode = HAL_I2C_ERROR_NONE;

	    /* Prepare transfer parameters */
	    hi2c->pBuffPtr  = pData;
	    hi2c->XferCount = size;
	    hi2c->XferISR   = NULL;

	    /* Send Slave Address */
	    /* Set NBYTES to write and reload if hi2c->XferCount > MAX_NBYTE_SIZE and generate RESTART */
	    if (hi2c->XferCount > MAX_NBYTE_SIZE)
	    {
	      hi2c->XferSize = MAX_NBYTE_SIZE;
	      I2C_TransferConfig(hi2c, DevAddress, (uint8_t)hi2c->XferSize, I2C_RELOAD_MODE, I2C_GENERATE_START_READ);
	    }
	    else
	    {
	      hi2c->XferSize = hi2c->XferCount;
	      I2C_TransferConfig(hi2c, DevAddress, (uint8_t)hi2c->XferSize, I2C_AUTOEND_MODE, I2C_GENERATE_START_READ);
	    }

	    while (hi2c->XferCount > 0U)
	    {
	      /* Wait until RXNE flag is set */
	      if (I2C_WaitOnRXNEFlagUntilTimeout(hi2c, Timeout, tickstart) != HAL_OK)
	      {
	        return HAL_ERROR;
	      }

	      /* Read data from RXDR */
	      *hi2c->pBuffPtr = (uint8_t)hi2c->Instance->RXDR;

	      /* Increment Buffer pointer */
	      hi2c->pBuffPtr++;

	      hi2c->XferSize--;
	      hi2c->XferCount--;

	      if ((hi2c->XferCount != 0U) && (hi2c->XferSize == 0U))
	      {
	        /* Wait until TCR flag is set */
	        if (I2C_WaitOnFlagUntilTimeout(hi2c, I2C_FLAG_TCR, RESET, Timeout, tickstart) != HAL_OK)
	        {
	          return HAL_ERROR;
	        }

	        if (hi2c->XferCount > MAX_NBYTE_SIZE)
	        {
	          hi2c->XferSize = MAX_NBYTE_SIZE;
	          I2C_TransferConfig(hi2c, DevAddress, (uint8_t)hi2c->XferSize, I2C_RELOAD_MODE, I2C_NO_STARTSTOP);
	        }
	        else
	        {
	          hi2c->XferSize = hi2c->XferCount;
	          I2C_TransferConfig(hi2c, DevAddress, (uint8_t)hi2c->XferSize, I2C_AUTOEND_MODE, I2C_NO_STARTSTOP);
	        }
	      }
	    }

	    /* No need to Check TC flag, with AUTOEND mode the stop is automatically generated */
	    /* Wait until STOPF flag is set */
	    if (I2C_WaitOnSTOPFlagUntilTimeout(hi2c, Timeout, tickstart) != HAL_OK)
	    {
	      return HAL_ERROR;
	    }

	    /* Clear STOP Flag */
	    __HAL_I2C_CLEAR_FLAG(hi2c, I2C_FLAG_STOPF);

	    /* Clear Configuration Register 2 */
	    I2C_RESET_CR2(hi2c);

	    hi2c->State = HAL_I2C_STATE_READY;
	    hi2c->Mode  = HAL_I2C_MODE_NONE;

	    /* Process Unlocked */
	    __HAL_UNLOCK(hi2c);

	    return HAL_OK;
}


